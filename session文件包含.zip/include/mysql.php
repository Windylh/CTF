
<?php

if (count(get_included_files()) == 1) {
	die();
}

$mysqli = new mysqli('localhost', 'root', 'root', 'cloud');
if (!$mysqli) {
	die("MySQL error\n");
}
