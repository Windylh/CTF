<?php

$lang = 'zh-CN';
$lang_eiscloud = 'web';
$lang_login = '登录';
$lang_register = '注册';
$lang_logout = '登出';
$lang_username = '用户名';
$lang_password = '密码';
$lang_password_again = '密码 (再次确认)';
$lang_login_failed = '登录失败';
$lang_register_failed = '注册失败 (用户已存在)';
$lang_register_success = '注册成功，请登录';
$lang_welcome = '欢迎，';
