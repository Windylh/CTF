<?php
header("Content-type: text/html; charset=utf-8");
if (count(get_included_files()) == 1) {
	die();
}

error_reporting(0);
ini_set('session.save_path', '/tmp/SESS');
//ini_set('session.save_path', './tmp');
session_start();

function require_login() {
	if (!isset($_SESSION['user']) || !$_SESSION['user']) {
		header('Location: ./action.php?module=php&file=login');
		die();
	}
}

if (!isset($_SESSION['lang']) || !$_SESSION['lang']) {
	$_SESSION['lang'] = 'zh-CN';
}
if (isset($_GET['lang'])) {
	$_SESSION['lang'] = $_GET['lang'];
}
$langfile = './include/lang.' . $_SESSION['lang'] . '.php';
if (file_exists($langfile)) {
	include $langfile;
} else {
	$_SESSION['lang'] = 'zh-CN';
	die('Unable to load translation file: ' . $langfile);
}
