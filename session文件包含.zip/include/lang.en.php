<?php

$lang = 'en';
$lang_eiscloud = 'web';
$lang_login = 'Sign in';
$lang_register = 'Sign up';
$lang_logout = 'Sign out';
$lang_username = 'User Name';
$lang_password = 'Password';
$lang_password_again = 'Password (Confirm)';
$lang_login_failed = 'Login failed';
$lang_register_failed = 'Unable to create account (Username already exists)';
$lang_register_success = 'Account created. Please sign in';
$lang_welcome = 'Welcome, ';
