
<?php

include_once './include/init.php';

if (isset($_GET['reg'])) {
	$message = '<div class="alert alert-success">' . $lang_register_success . '</div>';
}

if (isset($_POST['username']) && isset($_POST['password'])) {
	include './include/mysql.php';
	$success = false;
	$query = $mysqli->prepare('select name, password, uuid from user where name = ? and password = sha1(?)');
	$query->bind_param('ss', $_POST['username'], $_POST['password']);
	$query->execute();
	$query->bind_result($name, $password, $uuid);
	if ($query->fetch()) {
		$_SESSION['user'] = $name;
		$_SESSION['uuid'] = $uuid;
		$success = true;
		echo "1";
	}
	$query->close();
	$mysqli->close();
	if ($success) {
		header('Location: ./index.php');
		echo "2";
		die();
	} else {
		$message = '<div class="alert alert-danger">' . $lang_login_failed . '</div>';
	}
}

?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
	<title><?php echo $lang_eiscloud; ?></title>
	<link rel="stylesheet" href="./css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/bootstrap-theme.min.css">
	<script src="./js/jquery-3.1.1.min.js"></script>
	<script src="./js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<a class="navbar-brand" href="./"><?php echo $lang_eiscloud; ?></a>
            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="./action.php?module=php&file=login"><?php echo $lang_login; ?></a></li>
              <!--  <li><a href="./action.php?module=php&file=register"><?php echo $lang_register; ?></a></li>-->
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">&#x1F310; <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                    <li><a href="./action.php?module=php&file=login&lang=en">English</a></li>
                    <li><a href="./action.php?module=php&file=login&lang=zh-CN">中文</a></li>
                    </ul>
                </li>
            </ul>
		</div>
	</nav>
	<div class="container" style="max-width: 500px;">
		<form action="" method="POST">
            <?php echo $message; ?>
			<h4><?php echo $lang_login; ?></h4>
			<p><input type="text" name="username" class="form-control" placeholder="<?php echo $lang_username; ?>"  required /></p>
			<p><input type="password" name="password" class="form-control" placeholder="<?php echo $lang_password; ?>"  required /></p>
			<p><button class="btn btn-primary btn-block" type="submit"><?php echo $lang_login; ?></button></p>
		</form>
	</div>
</body>
</html>
