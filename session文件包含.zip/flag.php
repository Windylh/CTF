<?php
$flag = 'flag{45565c2e-010e-4784-9c66-13fd2deb9f31}';
?>
