
<?php

include_once './include/init.php';

if (isset($_POST['username']) && isset($_POST['password'])) {
	include './include/mysql.php';
	$success = false;
	$query = $mysqli->prepare('insert into user (name, password, uuid) values (?, sha1(?), uuid())');
	$query->bind_param('ss', $_POST['username'], $_POST['password']);
	$query->execute();
	$query->bind_result($name, $password, $uuid);
	if ($query->affected_rows > 0) {
		$success = true;
	}
	$query->close();
	$mysqli->close();
	if ($success) {
		header('Location: ./action.php?module=php&file=login&reg=true');
		die();
	} else {
		$message = '<div class="alert alert-danger">' . $lang_register_failed . '</div>';
	}
}

?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
	<title><?php echo $lang_eiscloud; ?></title>
	<link rel="stylesheet" href="./css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/bootstrap-theme.min.css">
	<script src="./js/jquery-3.1.1.min.js"></script>
	<script src="./js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<a class="navbar-brand" href="./"><?php echo $lang_eiscloud; ?></a>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="./action.php?module=php&file=login"><?php echo $lang_login; ?></a></li>
<!--                <li class="active"><a href="./action.php?module=php&file=register"><?php echo $lang_register; ?></a></li>-->
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">&#x1F310; <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                    <li><a href="./action.php?module=php&file=register&lang=en">English</a></li>
                    <li><a href="./action.php?module=php&file=register&lang=zh-CN">中文</a></li>
                    </ul>
                </li>
            </ul>
		</div>
	</nav>
	<div class="container" style="max-width: 500px;">
		<form action="" method="POST">
            <?php echo $message; ?>
			<h4><?php echo $lang_register; ?></h4>
			<p><input type="text" id="usr" name="username" class="form-control" placeholder="<?php echo $lang_username; ?>"  required /></p>
			<p><input type="password" id="pw1" name="password" class="form-control" placeholder="<?php echo $lang_password; ?>"  required /></p>
            <p><input type="password" id="pw2" class="form-control" placeholder="<?php echo $lang_password_again; ?>"  required /></p>
			<p><button class="btn btn-primary btn-block" id="submit" type="submit" disabled="true"><?php echo $lang_register; ?></button></p>
		</form>
	</div>
</body>
<script type="text/javascript">
    $(document).ready(function() {
        $("#usr, #pw1, #pw2").keyup(function() {
            if (!$("#usr").val() || !$("#pw1").val() || $("#pw1").val() != $("#pw2").val()) {
                $("#submit").prop('disabled', true);
            } else {
                $("#submit").prop('disabled', false);
            }
        });
    });
</script>
</html>
