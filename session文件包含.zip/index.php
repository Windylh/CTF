
<?php

include_once './include/init.php';

require_login();

?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
	<title><?php echo $lang_eiscloud; ?></title>
	<link rel="stylesheet" href="./css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/bootstrap-theme.min.css">
	<script src="./js/jquery-3.1.1.min.js"></script>
	<script src="./js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<a class="navbar-brand" href="./"><?php echo $lang_eiscloud; ?></a>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="./logout.php"><?php echo $lang_logout; ?></a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">&#x1F310; <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                    <li><a href="?lang=en">English</a></li>
                    <li><a href="?lang=zh-CN">中文</a></li>
                    </ul>
                </li>
            </ul>
		</div>
	</nav>
	<div class="container" style="max-width: 800px;">
        <?php echo $message; ?>
        <h4><?php echo $lang_welcome . htmlentities($_SESSION['user']); ?></h4>

        <p><b><?php echo "there is no flag"; ?></b></p>

	</div>
</body>
</html>
