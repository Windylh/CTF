<?php
include_once './include/init.php';
if (isset($_GET['file']) && isset($_GET['module'])) {
	$file = $_GET['file'];
	$module = $_GET['module'];
	if ($module === 'php') {
		include "./$file.$module";
	} else {
		if (file_exists("./$file")) {
echo $file;
echo "33333";
			include "./$file";
		} else {
			echo "the $file didn't exist";
		}
	}

} else {
	die();
}
